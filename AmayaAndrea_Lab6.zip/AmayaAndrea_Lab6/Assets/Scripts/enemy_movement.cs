﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemy_movement : MonoBehaviour
{
    public LayerMask enemyLayer;
    public float speed;
    private bool right = true;
    public float distance;
    private Rigidbody2D rb;
    private Transform tf;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        tf = GetComponent<Transform>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        transform.Translate(Vector2.right * speed * Time.deltaTime);
        RaycastHit2D enemy = Physics2D.Raycast(tf.position, Vector2.down, distance, enemyLayer);

        if (enemy.collider == false)
        {
            if (right == true)
            {
                transform.eulerAngles = new Vector3(0, -180, 0);
                right = false;
            } else
            {
                transform.eulerAngles = new Vector3(0, 0, 0);
                right = true;
            }
        }
    }
}
