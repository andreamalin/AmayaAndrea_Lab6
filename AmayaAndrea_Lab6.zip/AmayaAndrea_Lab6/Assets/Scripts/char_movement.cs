﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class char_movement : MonoBehaviour
{
    public Animator animator;
    public float moveSpeed;
    public Rigidbody2D rb;
    private Vector2 movement;
    public LayerMask groundLayer;
    public Boolean powerup;


    // Update is called once per frame
    private void Start()
    {
        
    }
    void Update()
    {
        movement.x=Input.GetAxisRaw("Horizontal");

        animator.SetFloat("Horizontal", movement.x);
        animator.SetFloat("Speed", movement.sqrMagnitude);


    }
    void FixedUpdate()
    {
        rb.MovePosition(rb.position + movement * moveSpeed * Time.fixedDeltaTime);
        RaycastHit2D hit = Physics2D.Raycast(transform.position, Vector2.down, 0.25f, groundLayer);
        
        if (hit.collider != null)
        {
            if (Input.GetKeyDown(KeyCode.Space))
            {
                rb.AddForce(Vector2.up*20f, ForceMode2D.Impulse);
            }
        }

    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("PowerUp"))
        {
            Destroy(collision.gameObject);
            powerup = true;
            transform.localScale += new Vector3(0.35f, 0.2f);

        }
        if (collision.gameObject.CompareTag("Enemy"))
        {
            if (powerup)
            {
                Destroy(collision.gameObject);
            } else
            {
                Destroy(gameObject);
            }

        }
    }


}
